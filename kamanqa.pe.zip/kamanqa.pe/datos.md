# Datos de la empresa


## Colores

- verdigris: #479bad
- coolgrey: #839ba7
- aguabella: #55a3b7
- azulnoche: #3e4557
- tuquesino: #1e6987

## fuentes

 helvetica

## Contenedor

ancho máximo de 1200px;